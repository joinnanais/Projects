# 20054483_patiag_fvq_autumn_2021

Programming for Data Science Coursework